<?php

// O Controlador é a peça de código que sabe qual classe chamar, para onde redirecionar e etc.
// Use o método $_GET para obter informações vindas de outras páginas.


require_once __DIR__."/../models/Produto.php";
require_once __DIR__."/../models/CrudProdutos.php";


if ($_GET['acao'] == 'cadastrar'){

    $produto = new Produto($_POST['nome'], $_POST['preco'], $_POST['categoria'], $_POST['quantidade']);

    $crud = new CrudProdutos();

    $crud->salvar($produto);


    header("location: ../views/admin/produtos.php");
}



if ( $_GET['acao'] == 'editar'){

    $codigo = $_GET['codigo'];

    $crud = new CrudProdutos();
    $crud->editar($codigo);

    header("location: ../views/admin/produtos.php");

}


if ( $_GET['acao'] == 'excluir'){

    $codigo = $_GET['codigo'];

    $crud = new CrudProdutos();
    $crud->excluir($codigo);
    header("location: ../views/admin/produtos.php");
}




